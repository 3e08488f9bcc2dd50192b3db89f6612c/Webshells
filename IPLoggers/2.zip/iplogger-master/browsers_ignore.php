<?php
$BROWSERS_TO_IGNORE = array(
	'TelegramBot(like TwitterBot)',
    'TelegramBot (like TwitterBot)',
    'bitlybot/3.0 (+http://bit.ly/)',
    'Mozilla/5.0 (compatible; Nimbostratus-Bot/v1.3.2; http://cloudsystemnetworks.com)',
    'Mozilla/5.0 (compatible; NetcraftSurveyAgent/1.0; +info@netcraft.com)',
    'Mozilla/5.0 zgrab/0.x'
);
?>
